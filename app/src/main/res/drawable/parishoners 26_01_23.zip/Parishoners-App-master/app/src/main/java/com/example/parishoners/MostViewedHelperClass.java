package com.example.parishoners;

public class MostViewedHelperClass {

    int image;
    String title;

    public MostViewedHelperClass(int image, String title) {
        this.image = image;
        this.title = title;

    }

    public int getImage() {
        return image;
    }

    public String getTitle() {
        return title;
    }


}
